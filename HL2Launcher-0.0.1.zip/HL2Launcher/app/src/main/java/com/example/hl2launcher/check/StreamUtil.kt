package com.example.hl2launcher.check

import java.io.ByteArrayOutputStream
import java.io.InputStream

internal fun InputStream.readCapped(max: Int): ByteArray {
    val out = ByteArrayOutputStream()
    val buf = ByteArray(8192)
    var total = 0
    while (total < max) {
        val r = read(buf, 0, minOf(buf.size, max - total))
        if (r < 0) break
        out.write(buf, 0, r)
        total += r
    }
    return out.toByteArray()
}
