package com.example.hl2launcher.controls

/**
 * Все кнопки управления. press — консольная команда Source.
 * hold = true: на нажатие шлём "+cmd", на отпускание "-cmd".
 * Пустая команда = служебная кнопка самого приложения (Настройки, Панель).
 * defX/defY — центр кнопки в долях экрана, defSize — диаметр в долях высоты.
 */
enum class ControlAction(
    val id: String, val label: String, val press: String, val hold: Boolean,
    val defX: Float, val defY: Float, val defSize: Float = 0.15f
) {
    FORWARD("forward", "Вперёд", "+forward", true, 0.13f, 0.55f),
    BACK("back", "Назад", "+back", true, 0.13f, 0.85f),
    LEFT("left", "Влево", "+moveleft", true, 0.05f, 0.70f),
    RIGHT("right", "Вправо", "+moveright", true, 0.21f, 0.70f),
    SPRINT("sprint", "Бег", "+speed", true, 0.31f, 0.85f),
    CROUCH("crouch", "Присесть", "+duck", true, 0.31f, 0.62f),
    FIRE("fire", "Огонь", "+attack", true, 0.88f, 0.62f, 0.20f),
    AIM("aim", "Прицел", "+zoom", true, 0.76f, 0.42f),
    JUMP("jump", "Прыжок", "+jump", true, 0.79f, 0.83f),
    USE("use", "Использовать", "+use", true, 0.94f, 0.38f),
    RELOAD("reload", "Перезарядка", "+reload", true, 0.67f, 0.83f),
    FLASHLIGHT("flashlight", "Фонарь", "impulse 100", false, 0.58f, 0.85f),
    SLOT1("slot1", "Оружие 1", "slot1", false, 0.30f, 0.09f, 0.12f),
    SLOT2("slot2", "Оружие 2", "slot2", false, 0.36f, 0.09f, 0.12f),
    SLOT3("slot3", "Оружие 3", "slot3", false, 0.42f, 0.09f, 0.12f),
    SLOT4("slot4", "Оружие 4", "slot4", false, 0.48f, 0.09f, 0.12f),
    SLOT5("slot5", "Оружие 5", "slot5", false, 0.54f, 0.09f, 0.12f),
    SLOT6("slot6", "Оружие 6", "slot6", false, 0.60f, 0.09f, 0.12f),
    PREV_WEAPON("prev_weapon", "Пред. оружие", "invprev", false, 0.22f, 0.09f, 0.12f),
    NEXT_WEAPON("next_weapon", "След. оружие", "invnext", false, 0.68f, 0.09f, 0.12f),
    LAST_WEAPON("last_weapon", "Прошлое оружие", "lastinv", false, 0.75f, 0.09f, 0.12f),
    SAVE("save", "Сохранить игру", "quicksave", false, 0.86f, 0.09f, 0.12f),
    LOAD("load", "Загрузить игру", "quickload", false, 0.92f, 0.09f, 0.12f),
    MENU("menu", "Меню", "gamemenu", false, 0.04f, 0.09f, 0.12f),
    CONSOLE("console", "Консоль", "toggleconsole", false, 0.10f, 0.09f, 0.12f),
    PAUSE("pause", "Пауза", "pause", false, 0.96f, 0.24f, 0.12f),
    SCREENSHOT("screenshot", "Скриншот", "jpeg", false, 0.96f, 0.38f, 0.12f),
    SETTINGS("settings", "Настройки", "", false, 0.04f, 0.24f, 0.12f),
    PANEL("panel", "Панель", "", false, 0.10f, 0.24f, 0.12f);

    val special: Boolean get() = press.isEmpty()

    companion object {
        /** Кнопки, которые прячутся/показываются кнопкой «Панель». */
        val PANEL_GROUP = setOf(
            SLOT1, SLOT2, SLOT3, SLOT4, SLOT5, SLOT6,
            PREV_WEAPON, NEXT_WEAPON, LAST_WEAPON,
            SAVE, LOAD, CONSOLE, PAUSE, SCREENSHOT
        )
    }
}
