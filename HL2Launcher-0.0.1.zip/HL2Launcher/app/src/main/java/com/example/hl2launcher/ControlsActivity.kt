package com.example.hl2launcher

import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.hl2launcher.controls.ControlAction
import com.example.hl2launcher.controls.ControlLayout
import com.example.hl2launcher.controls.GameControlsView
import com.example.hl2launcher.controls.InputSink

/** Экран проверки и настройки кнопок управления. */
class ControlsActivity : AppCompatActivity() {
    private lateinit var layoutData: ControlLayout
    private lateinit var controls: GameControlsView
    private lateinit var log: TextView
    private lateinit var editBar: LinearLayout

    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY

        layoutData = ControlLayout(this)
        val root = FrameLayout(this).apply { setBackgroundColor(Color.parseColor("#202020")) }

        log = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 18f; gravity = Gravity.CENTER
            text = "Режим проверки.\nНажимай кнопки — здесь появится команда.\nКнопка настроек — редактор раскладки."
        }
        root.addView(log, FrameLayout.LayoutParams(-1, -1))

        val sink = object : InputSink {
            override fun command(cmd: String) { runOnUiThread { log.text = "→ $cmd" } }
        }
        controls = GameControlsView(this, layoutData, sink) { a ->
            when (a) {
                ControlAction.SETTINGS -> toggleEdit()
                ControlAction.PANEL -> { controls.panelVisible = !controls.panelVisible; controls.invalidate() }
                else -> {}
            }
        }
        root.addView(controls, FrameLayout.LayoutParams(-1, -1))

        editBar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; visibility = View.GONE }
        editBar.addView(Button(this).apply { text = "Сохранить"; setOnClickListener { layoutData.save(); log.text = "Раскладка сохранена" } })
        editBar.addView(Button(this).apply { text = "Сбросить"; setOnClickListener { layoutData.reset(); controls.invalidate() } })
        editBar.addView(Button(this).apply { text = "Готово"; setOnClickListener { layoutData.save(); toggleEdit() } })
        root.addView(editBar, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL))

        setContentView(root)
    }

    private fun toggleEdit() {
        controls.editMode = !controls.editMode
        editBar.visibility = if (controls.editMode) View.VISIBLE else View.GONE
        log.text = if (controls.editMode) "Редактор: перетаскивай кнопки" else "Режим проверки"
        controls.invalidate()
    }
}
