package com.example.hl2launcher

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.StatFs
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.documentfile.provider.DocumentFile
import com.example.hl2launcher.check.CheckIssue
import com.example.hl2launcher.check.ErrorType
import com.example.hl2launcher.check.GameVerifier
import com.example.hl2launcher.check.ReportFormatter
import com.example.hl2launcher.check.TreeGameSource
import com.example.hl2launcher.check.VerifyResult
import com.example.hl2launcher.check.ZipGameSource
import com.example.hl2launcher.controls.BindsWriter
import com.example.hl2launcher.settings.FpsSettings
import java.io.File
import java.util.zip.ZipException
import java.util.zip.ZipInputStream
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {
    private lateinit var status: TextView
    private lateinit var launchBtn: Button
    private lateinit var folderBtn: Button
    private lateinit var zipBtn: Button
    private val gameRoot by lazy { File(getExternalFilesDir(null), "hl2data") }

    private val pickFolder = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) {
        if (it != null) importFolder(it)
    }
    private val pickZip = registerForActivityResult(ActivityResultContracts.OpenDocument()) {
        if (it != null) importZip(it)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad, pad, pad) }
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        folderBtn = Button(this).apply { text = "Выбрать папку с игрой"; setOnClickListener { pickFolder.launch(null) } }
        zipBtn = Button(this).apply { text = "Выбрать ZIP с игрой"; setOnClickListener { pickZip.launch(arrayOf("application/zip", "application/x-zip-compressed", "*/*")) } }
        launchBtn = Button(this).apply { text = "Запустить Half-Life 2"; isEnabled = false; setOnClickListener { launchGame() } }
        folderBtn.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_folder, 0, 0, 0)
        zipBtn.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_zip, 0, 0, 0)
        launchBtn.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_play, 0, 0, 0)
        for (b in listOf(folderBtn, zipBtn, launchBtn)) b.compoundDrawablePadding = pad / 2
        val ctrlBtn = Button(this).apply {
            text = "Кнопки управления"
            setOnClickListener { startActivity(Intent(this@MainActivity, ControlsActivity::class.java)) }
        }
        val bindBtn = Button(this).apply {
            text = "Записать привязки клавиш"
            setOnClickListener {
                say(if (BindsWriter.write(gameRoot, FpsSettings.load(this@MainActivity))) "Привязки записаны в hl2/cfg/autoexec.cfg"
                    else "Сначала загрузи и проверь файлы игры.")
            }
        }
        status = TextView(this).apply { textSize = 15f; setPadding(0, pad, 0, 0) }
        col.addView(folderBtn, lp); col.addView(zipBtn, lp); col.addView(launchBtn, lp)
        col.addView(ctrlBtn, lp); col.addView(bindBtn, lp)

        // --- Ограничение FPS: шкала и быстрые кнопки ---
        val fpsLabel = TextView(this).apply { textSize = 16f; setPadding(0, pad, 0, 0) }
        val fpsBar = SeekBar(this).apply { max = FpsSettings.STEPS.size - 1 }
        val fpsNow = FpsSettings.load(this)
        fpsBar.progress = FpsSettings.STEPS.indexOf(fpsNow)
        fpsLabel.text = "FPS: $fpsNow"
        fpsBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                fpsLabel.text = "FPS: ${FpsSettings.STEPS[p]}"
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) { applyFps(FpsSettings.STEPS[sb?.progress ?: 0]) }
        })
        val presets = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (v in listOf(30, 60, 120)) {
            presets.addView(Button(this).apply {
                text = "FPS $v"
                setOnClickListener { fpsBar.progress = FpsSettings.STEPS.indexOf(v); applyFps(v) }
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        col.addView(fpsLabel, lp); col.addView(fpsBar, lp); col.addView(presets, lp)
        col.addView(ScrollView(this).apply { addView(status) }, lp)
        setContentView(col)

        if (GameChecker.missingInDir(gameRoot).isEmpty()) {
            say("HL2 Launcher $versionName\nФайлы игры уже загружены и проверены.")
            launchBtn.isEnabled = true
        } else {
            say("HL2 Launcher $versionName\nСкинь файлы игры: папку Half-Life 2 (где лежат hl2 и platform) или ZIP с ними.\n" +
                "Лучше выбрать папку steamapps: тогда приложение прочитает и манифест Steam.\n" +
                "Игра в приложение не встроена — нужна твоя копия.")
        }
    }

    private val versionName: String get() = try {
        packageManager.getPackageInfo(packageName, 0).versionName ?: "?"
    } catch (e: Exception) { "?" }

    private fun applyFps(fps: Int) {
        FpsSettings.save(this, fps)
        say(if (BindsWriter.write(gameRoot, fps)) "FPS ограничен до $fps (записано в hl2/cfg/autoexec.cfg)."
            else "FPS $fps сохранён. Применится при запуске после загрузки игры.")
    }

    private fun say(s: String) = runOnUiThread { status.text = s }
    private fun busy(b: Boolean) = runOnUiThread { folderBtn.isEnabled = !b; zipBtn.isEnabled = !b }

    private fun freeBytes(): Long? = try {
        StatFs((getExternalFilesDir(null) ?: filesDir).path).availableBytes
    } catch (e: Exception) { null }

    /** Показывает отчёт в тексте и окошком: ошибка / предупреждение / успех. */
    private fun showResult(r: VerifyResult) {
        say(ReportFormatter.format(r))
        val first = r.errors.firstOrNull()
        val icon = when {
            first == null -> if (r.warnings.isEmpty()) R.drawable.status_ok else R.drawable.status_warning
            first?.type == ErrorType.OTHER_GAME || first?.type == ErrorType.OTHER_GAME_FILES -> R.drawable.status_other_game
            first?.type == ErrorType.LICENSE_BAD -> R.drawable.status_license
            else -> R.drawable.status_error
        }
        val title = if (first != null) "Ошибка ${first.type.code}" else "Проверка пройдена"
        val msg = if (first != null) ReportFormatter.title(first)
            else (r.license?.describe() ?: "Манифест Steam не найден: лицензию проверить не удалось.")
        runOnUiThread {
            AlertDialog.Builder(this).setIcon(icon).setTitle(title).setMessage(msg)
                .setPositiveButton("OK", null).show()
        }
    }

    private fun fail(type: ErrorType, detail: String = "") =
        showResult(VerifyResult(listOf(CheckIssue(type, detail)), null, null))

    private fun finishCheck(result: VerifyResult) {
        val missing = GameChecker.missingInDir(gameRoot)
        if (missing.isEmpty()) {
            try { File(gameRoot, "check_report.txt").writeText(ReportFormatter.format(result)) } catch (e: Exception) { }
            runOnUiThread {
                status.append("\n\nФайлы скопированы, можно запускать.")
                launchBtn.isEnabled = true
            }
        } else {
            fail(ErrorType.MISSING_FILES, missing.joinToString("\n") { "• $it" })
        }
        busy(false)
    }

    private fun importFolder(uri: Uri) {
        busy(true); say("Проверяю папку…")
        thread {
            try {
                val root = DocumentFile.fromTreeUri(this, uri)
                if (root == null) { fail(ErrorType.IO_ERROR, "не удалось открыть папку"); busy(false); return@thread }
                val base = GameChecker.findBase(root) ?: root
                val result = GameVerifier.verify(TreeGameSource(this, base, root), freeBytes())
                showResult(result)
                if (!result.ok) { busy(false); return@thread }
                for (d in GameChecker.COPY_DIRS) {
                    val src = base.findFile(d) ?: continue
                    copyTree(src, File(gameRoot, d))
                }
                finishCheck(result)
            } catch (e: Exception) {
                fail(ErrorType.IO_ERROR, e.message ?: e.toString()); busy(false)
            }
        }
    }

    private fun copyTree(src: DocumentFile, dst: File) {
        dst.mkdirs()
        for (c in src.listFiles()) {
            val name = c.name ?: continue
            if (c.isDirectory) { copyTree(c, File(dst, name)); continue }
            val out = File(dst, name)
            if (out.exists() && out.length() == c.length()) continue
            say("Копирую: ${dst.name}/$name")
            contentResolver.openInputStream(c.uri)?.use { i -> out.outputStream().use { o -> i.copyTo(o, 1 shl 16) } }
        }
    }

    private fun importZip(uri: Uri) {
        busy(true); say("Проверяю ZIP (это может занять время)…")
        thread {
            try {
                val src = try {
                    ZipGameSource.scan(this, uri)
                } catch (e: ZipException) {
                    fail(ErrorType.ZIP_BROKEN, e.message ?: ""); busy(false); return@thread
                }
                val result = GameVerifier.verify(src, freeBytes())
                showResult(result)
                if (!result.ok) { busy(false); return@thread }
                val prefix = src.extractPrefix
                val rootCanon = gameRoot.apply { mkdirs() }.canonicalFile
                ZipInputStream(contentResolver.openInputStream(uri)!!.buffered()).use { z ->
                    var e = z.nextEntry
                    while (e != null) {
                        val n = e.name.replace('\\', '/')
                        if (!e.isDirectory && n.startsWith(prefix)) {
                            val rel = n.removePrefix(prefix)
                            if (GameChecker.COPY_DIRS.any { rel.startsWith("$it/") }) {
                                val out = File(gameRoot, rel).canonicalFile
                                if (out.path.startsWith(rootCanon.path + File.separator)) { // защита от zip-slip
                                    out.parentFile?.mkdirs()
                                    say("Распаковываю: $rel")
                                    out.outputStream().use { z.copyTo(it, 1 shl 16) }
                                }
                            }
                        }
                        e = z.nextEntry
                    }
                }
                finishCheck(result)
            } catch (e: Exception) {
                fail(ErrorType.IO_ERROR, e.message ?: e.toString()); busy(false)
            }
        }
    }

    private fun launchGame() {
        val i = packageManager.getLaunchIntentForPackage(Config.ENGINE_PACKAGE)
        if (i == null) { fail(ErrorType.ENGINE_MISSING, Config.ENGINE_PACKAGE); return }
        BindsWriter.write(gameRoot, FpsSettings.load(this))
        i.putExtra(Config.EXTRA_GAMEDIR, gameRoot.absolutePath)
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(i)
    }
}
