package com.example.hl2launcher.check

object ReportFormatter {
    fun title(i: CheckIssue): String =
        if (i.type.inline && i.detail.isNotBlank()) "${i.type.title}: ${i.detail}" else i.type.title

    fun format(r: VerifyResult): String {
        val sb = StringBuilder()
        for (e in r.errors) {
            sb.append("❌ Ошибка ").append(e.type.code).append(": ").append(title(e)).append('\n')
            if (!e.type.inline && e.detail.isNotBlank()) sb.append(e.detail).append('\n')
            sb.append("→ ").append(e.type.hint).append("\n\n")
        }
        for (w in r.warnings) {
            sb.append("⚠ ").append(w.type.code).append(": ").append(title(w)).append('\n')
            sb.append("→ ").append(w.type.hint).append("\n\n")
        }
        r.license?.let { sb.append("🔑 Steam (манифест установки): ").append(it.describe()).append('\n') }
        r.gameTitle?.let { sb.append("🎮 Игра: ").append(it).append('\n') }
        if (r.ok) sb.append("✔ Проверка пройдена.")
        return sb.toString().trim()
    }
}
