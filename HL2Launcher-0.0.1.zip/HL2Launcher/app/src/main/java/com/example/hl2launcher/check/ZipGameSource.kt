package com.example.hl2launcher.check

import android.content.Context
import android.net.Uri
import java.io.ByteArrayOutputStream
import java.util.zip.ZipInputStream

/** Один проход по ZIP: размеры файлов, маленькие текстовые файлы и первые 4 байта у .vpk. */
class ZipGameSource private constructor(
    val extractPrefix: String,
    private val sizes: Map<String, Long>,
    private val texts: Map<String, String>,
    private val heads: Map<String, ByteArray>,
    private val manifest: String?
) : GameSource {

    override fun size(path: String): Long = sizes[extractPrefix + path] ?: -1L
    override fun head(path: String, n: Int): ByteArray? = heads[extractPrefix + path]?.let { it.copyOf(minOf(n, it.size)) }
    override fun text(path: String): String? = texts[extractPrefix + path]
    override fun manifestText(): String? = manifest

    override fun topDirs(): List<String> = sizes.keys
        .filter { it.startsWith(extractPrefix) }
        .map { it.removePrefix(extractPrefix) }
        .filter { it.contains('/') }
        .map { it.substringBefore('/') }
        .distinct()

    override fun totalSize(dirs: List<String>): Long = sizes.filter { (k, _) ->
        k.startsWith(extractPrefix) && dirs.any { k.removePrefix(extractPrefix).startsWith("$it/") }
    }.values.sum()

    companion object {
        fun scan(ctx: Context, uri: Uri): ZipGameSource {
            val sizes = HashMap<String, Long>()
            val texts = HashMap<String, String>()
            val heads = HashMap<String, ByteArray>()
            var manifest: String? = null
            val input = ctx.contentResolver.openInputStream(uri) ?: throw java.io.IOException("не удалось открыть файл")
            ZipInputStream(input.buffered()).use { z ->
                val buf = ByteArray(1 shl 16)
                var e = z.nextEntry
                while (e != null) {
                    if (!e.isDirectory) {
                        val name = e.name.replace('\\', '/')
                        val keepText = name.endsWith("gameinfo.txt") || name.endsWith("steam_appid.txt") ||
                            name.endsWith("appmanifest_220.acf")
                        val keepHead = name.endsWith(".vpk")
                        val bos = if (keepText) ByteArrayOutputStream() else null
                        var total = 0L
                        while (true) {
                            val r = z.read(buf)
                            if (r < 0) break
                            if (keepHead && !heads.containsKey(name) && r > 0) heads[name] = buf.copyOf(minOf(r, 4))
                            if (bos != null && total < 262144) bos.write(buf, 0, r)
                            total += r
                        }
                        sizes[name] = total
                        if (bos != null) {
                            val txt = String(bos.toByteArray(), Charsets.UTF_8)
                            if (name.endsWith("appmanifest_220.acf")) manifest = txt else texts[name] = txt
                        }
                    }
                    e = z.nextEntry
                }
            }
            val prefix = sizes.keys.firstOrNull { it.endsWith("hl2/gameinfo.txt") }?.removeSuffix("hl2/gameinfo.txt") ?: ""
            return ZipGameSource(prefix, sizes, texts, heads, manifest)
        }
    }
}
