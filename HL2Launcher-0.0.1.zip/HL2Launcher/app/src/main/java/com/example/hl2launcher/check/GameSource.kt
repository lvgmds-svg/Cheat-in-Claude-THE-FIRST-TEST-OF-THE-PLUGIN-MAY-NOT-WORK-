package com.example.hl2launcher.check

/** Откуда читаем игру: папка на диске, папка через SAF или ZIP. Пути — относительно папки Half-Life 2. */
interface GameSource {
    /** Размер файла, -1 если файла нет. */
    fun size(path: String): Long
    fun head(path: String, n: Int): ByteArray?
    fun text(path: String): String?
    fun topDirs(): List<String>
    fun totalSize(dirs: List<String>): Long
    /** Текст appmanifest_220.acf, если он найден рядом. */
    fun manifestText(): String?
}
