package com.example.hl2launcher.controls

import com.example.hl2launcher.settings.FpsSettings
import java.io.File

/** Пишет hl2/cfg/autoexec.cfg с привязками клавиш (копия лежит в docs/autoexec.cfg). */
object BindsWriter {
    private val CFG = """// HL2 Launcher: привязки управления (клавиатура / мышь / геймпад через клавиши)
bind "w" "+forward"
bind "s" "+back"
bind "a" "+moveleft"
bind "d" "+moveright"
bind "space" "+jump"
bind "ctrl" "+duck"
bind "shift" "+speed"
bind "e" "+use"
bind "r" "+reload"
bind "f" "impulse 100"
bind "z" "+zoom"
bind "mouse1" "+attack"
bind "mouse2" "+attack2"
bind "mwheelup" "invprev"
bind "mwheeldown" "invnext"
bind "q" "lastinv"
bind "1" "slot1"
bind "2" "slot2"
bind "3" "slot3"
bind "4" "slot4"
bind "5" "slot5"
bind "6" "slot6"
bind "f5" "quicksave"
bind "f9" "quickload"
bind "`" "toggleconsole"
bind "pause" "pause"
bind "f12" "jpeg"
"""

    fun write(gameRoot: File, fps: Int = FpsSettings.DEFAULT): Boolean {
        val hl2 = File(gameRoot, "hl2")
        if (!hl2.isDirectory) return false
        val cfgDir = File(hl2, "cfg")
        cfgDir.mkdirs()
        File(cfgDir, "autoexec.cfg").writeText(CFG + "\n// Ограничение FPS\n" + FpsSettings.cfgLine(fps) + "\n")
        return true
    }
}
