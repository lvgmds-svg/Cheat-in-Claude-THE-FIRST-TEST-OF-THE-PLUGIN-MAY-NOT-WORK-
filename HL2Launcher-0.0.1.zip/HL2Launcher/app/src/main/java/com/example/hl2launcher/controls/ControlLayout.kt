package com.example.hl2launcher.controls

import android.content.Context
import org.json.JSONObject
import java.io.File

class ButtonState(var x: Float, var y: Float, var size: Float)

class ControlLayout(private val ctx: Context) {
    val map = LinkedHashMap<ControlAction, ButtonState>()
    private val file get() = File(ctx.filesDir, "controls_layout.json")

    init { reset(); load() }

    fun reset() {
        map.clear()
        for (a in ControlAction.values()) map[a] = ButtonState(a.defX, a.defY, a.defSize)
    }

    fun move(a: ControlAction, x: Float, y: Float) {
        val s = map[a] ?: return
        s.x = x.coerceIn(0f, 1f)
        s.y = y.coerceIn(0f, 1f)
    }

    fun save() {
        val root = JSONObject()
        for ((a, s) in map) {
            root.put(a.id, JSONObject().put("x", s.x.toDouble()).put("y", s.y.toDouble()).put("s", s.size.toDouble()))
        }
        file.writeText(root.toString())
    }

    private fun load() {
        if (!file.exists()) return
        try {
            val root = JSONObject(file.readText())
            for (a in ControlAction.values()) {
                val o = root.optJSONObject(a.id) ?: continue
                val st = map[a] ?: continue
                st.x = o.optDouble("x", st.x.toDouble()).toFloat()
                st.y = o.optDouble("y", st.y.toDouble()).toFloat()
                st.size = o.optDouble("s", st.size.toDouble()).toFloat()
            }
        } catch (e: Exception) { /* битый файл — остаются значения по умолчанию */ }
    }
}
