package com.example.hl2launcher.check

/** Виды ошибок (E..) и предупреждений (W..). inline = деталь выводится в одной строке с заголовком. */
enum class ErrorType(
    val code: String, val title: String, val hint: String,
    val fatal: Boolean = true, val inline: Boolean = false
) {
    NOT_SOURCE_GAME("E01", "Это не папка игры Source",
        "Выбери папку Half-Life 2: внутри должны лежать hl2 и platform."),
    OTHER_GAME("E02", "Обнаружена другая игра",
        "Нужна именно Half-Life 2 (Steam AppID 220).", inline = true),
    OTHER_GAME_FILES("E03", "Обнаружена другая игра рядом с Half-Life 2",
        "Оставь только hl2 и platform или отключи строгий режим (Config.STRICT_OTHER_GAMES).", inline = true),
    MISSING_FILES("E04", "Не хватает файлов игры",
        "В Steam: Свойства → Установленные файлы → Проверить целостность файлов."),
    CORRUPT_FILE("E05", "Файл игры повреждён",
        "Файл пустой или это не архив VPK. Скопируй игру заново."),
    APPID_MISMATCH("E06", "AppID в steam_appid.txt не совпадает с Half-Life 2 (220)",
        "Это файлы другой игры или изменённая копия."),
    LICENSE_BAD("E07", "Манифест Steam: игра установлена не полностью или это другая игра",
        "Дождись окончания установки/обновления в Steam и проверь целостность файлов."),
    NO_SPACE("E08", "Не хватает места на телефоне",
        "Освободи место во внутренней памяти и повтори."),
    ZIP_BROKEN("E09", "ZIP повреждён или не читается",
        "Перепакуй архив (обычный ZIP, без пароля) или выбери папку."),
    IO_ERROR("E10", "Ошибка чтения или записи файлов",
        "Проверь доступ к папке и свободное место."),
    ENGINE_MISSING("E11", "Движок не найден",
        "Установи порт Source Engine и впиши его package name в Config.kt и AndroidManifest.xml."),
    LICENSE_NOT_FOUND("W01", "Манифест Steam (appmanifest_220.acf) не найден",
        "Лицензию проверить не удалось. Выбери папку steamapps, чтобы приложение прочитало манифест.", fatal = false)
}
