package com.example.hl2launcher.check

import com.example.hl2launcher.Config
import com.example.hl2launcher.GameChecker

object GameVerifier {
    val CHUNKS = listOf(
        "hl2/hl2_pak_000.vpk", "hl2/hl2_textures_000.vpk", "hl2/hl2_misc_000.vpk",
        "hl2/hl2_sound_misc_000.vpk", "hl2/hl2_sound_vo_english_000.vpk",
        "platform/platform_misc_000.vpk"
    )
    val DIR_VPKS: List<String> = GameChecker.REQUIRED.filter { it.endsWith("_dir.vpk") }

    private fun isVpk(b: ByteArray?) = b != null && b.size >= 4 &&
        b[0] == 0x34.toByte() && b[1] == 0x12.toByte() && b[2] == 0xAA.toByte() && b[3] == 0x55.toByte()

    private fun fmt(bytes: Long) = String.format("%.1f ГБ", bytes / 1073741824.0)

    fun verify(
        src: GameSource,
        freeBytes: Long? = null,
        strict: Boolean = Config.STRICT_OTHER_GAMES
    ): VerifyResult {
        val issues = ArrayList<CheckIssue>()
        val dirs = src.topDirs()

        // 1. Это вообще Half-Life 2? Или другая игра?
        if (!dirs.contains("hl2")) {
            val others = dirs.filter { src.size("$it/gameinfo.txt") > 0 }
            issues += if (others.isEmpty()) CheckIssue(ErrorType.NOT_SOURCE_GAME)
            else CheckIssue(ErrorType.OTHER_GAME, others.joinToString { KnownGames.dirTitle(it) })
            return VerifyResult(issues, null, null)
        }

        val gi = src.text("hl2/gameinfo.txt")?.let { GameInfoParser.parse(it) }
        if (gi != null) {
            val id = gi.appId
            val title = gi.title
            if (id != null && id != KnownGames.HL2_APPID) {
                issues += CheckIssue(ErrorType.OTHER_GAME, "${KnownGames.name(id)} (AppID $id)")
            } else if (title != null && !title.contains("Half-Life 2", ignoreCase = true)) {
                issues += CheckIssue(ErrorType.OTHER_GAME, title)
            }
        }

        // 2. Файлы других игр рядом
        if (strict) {
            val extra = dirs.filter { KnownGames.OTHER_DIRS.containsKey(it) }
            if (extra.isNotEmpty()) {
                issues += CheckIssue(ErrorType.OTHER_GAME_FILES, extra.joinToString { KnownGames.dirTitle(it) })
            }
        }

        // 3. Нужные файлы
        val missing = (GameChecker.REQUIRED + CHUNKS).filter { src.size(it) < 0L }
        if (missing.isNotEmpty()) {
            issues += CheckIssue(ErrorType.MISSING_FILES, missing.joinToString("\n") { "• $it" })
        }

        // 4. Целостность: пустые файлы и подпись VPK (34 12 AA 55)
        val corrupt = DIR_VPKS.filter { p ->
            val s = src.size(p)
            s == 0L || (s > 0 && !isVpk(src.head(p, 4)))
        }
        if (corrupt.isNotEmpty()) {
            issues += CheckIssue(ErrorType.CORRUPT_FILE, corrupt.joinToString("\n") { "• $it" })
        }

        // 5. steam_appid.txt
        val appTxt = src.text("steam_appid.txt")?.trim()?.toIntOrNull()
        if (appTxt != null && appTxt != KnownGames.HL2_APPID) {
            issues += CheckIssue(ErrorType.APPID_MISMATCH, "в файле: $appTxt")
        }

        // 6. Манифест установки Steam
        var lic: LicenseInfo? = null
        val acf = src.manifestText()?.let { AcfParser.parse(it) }
        if (acf == null) {
            issues += CheckIssue(ErrorType.LICENSE_NOT_FOUND)
        } else {
            lic = LicenseInfo.from(acf)
            val st = lic.state
            if (lic.appId != null && lic.appId != KnownGames.HL2_APPID) {
                issues += CheckIssue(ErrorType.LICENSE_BAD, "AppID ${lic.appId}")
            } else if (st != null && st != 4) {
                issues += CheckIssue(ErrorType.LICENSE_BAD, "StateFlags=$st (нужно 4: установлено полностью)")
            }
        }

        // 7. Место на телефоне
        if (freeBytes != null) {
            val need = src.totalSize(GameChecker.COPY_DIRS)
            if (need > 0 && freeBytes < need + need / 20) {
                issues += CheckIssue(ErrorType.NO_SPACE, "нужно ${fmt(need)}, свободно ${fmt(freeBytes)}")
            }
        }

        return VerifyResult(issues, lic, gi?.title)
    }
}
