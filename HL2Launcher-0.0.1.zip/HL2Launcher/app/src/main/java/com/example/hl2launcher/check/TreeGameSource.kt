package com.example.hl2launcher.check

import android.content.Context
import androidx.documentfile.provider.DocumentFile

/** Чтение игры из папки, выбранной через системный выбор (SAF). */
class TreeGameSource(
    private val ctx: Context,
    private val base: DocumentFile,
    private val root: DocumentFile
) : GameSource {

    private fun find(path: String): DocumentFile? {
        var cur: DocumentFile? = base
        for (p in path.split('/')) cur = cur?.findFile(p)
        return cur
    }

    private fun read(f: DocumentFile, max: Int): ByteArray? = try {
        ctx.contentResolver.openInputStream(f.uri)?.use { it.readCapped(max) }
    } catch (e: Exception) { null }

    override fun size(path: String): Long {
        val f = find(path)
        return if (f != null && f.isFile) f.length() else -1L
    }

    override fun head(path: String, n: Int): ByteArray? = find(path)?.let { read(it, n) }

    override fun text(path: String): String? =
        find(path)?.takeIf { it.isFile }?.let { read(it, 262144) }?.let { String(it, Charsets.UTF_8) }

    override fun topDirs(): List<String> =
        base.listFiles().filter { it.isDirectory }.mapNotNull { it.name }

    private fun sizeOf(f: DocumentFile): Long =
        if (f.isDirectory) f.listFiles().sumOf { sizeOf(it) } else f.length()

    override fun totalSize(dirs: List<String>): Long =
        dirs.sumOf { d -> base.findFile(d)?.let { sizeOf(it) } ?: 0L }

    override fun manifestText(): String? {
        val f = root.findFile("appmanifest_220.acf")
            ?: root.findFile("steamapps")?.findFile("appmanifest_220.acf")
            ?: return null
        return read(f, 262144)?.let { String(it, Charsets.UTF_8) }
    }
}
