package com.example.hl2launcher.check

data class GameInfo(val title: String?, val appId: Int?)

object GameInfoParser {
    private val TITLE = Regex("(?im)^\\s*game\\s+\"([^\"]+)\"")
    private val APPID = Regex("(?i)SteamAppId\\s+\"?(\\d+)\"?")

    fun parse(text: String): GameInfo = GameInfo(
        TITLE.find(text)?.groupValues?.get(1),
        APPID.find(text)?.groupValues?.get(1)?.toIntOrNull()
    )
}
