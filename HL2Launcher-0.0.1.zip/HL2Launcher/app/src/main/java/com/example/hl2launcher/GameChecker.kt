package com.example.hl2launcher

import androidx.documentfile.provider.DocumentFile
import java.io.File

object GameChecker {
    // Минимальный набор файлов Half-Life 2 (Steam, версия на VPK)
    val REQUIRED = listOf(
        "hl2/gameinfo.txt",
        "hl2/hl2_pak_dir.vpk",
        "hl2/hl2_textures_dir.vpk",
        "hl2/hl2_misc_dir.vpk",
        "hl2/hl2_sound_misc_dir.vpk",
        "hl2/hl2_sound_vo_english_dir.vpk",
        "platform/platform_misc_dir.vpk"
    )
    val COPY_DIRS = listOf("hl2", "platform")

    fun missingInDir(dir: File) = REQUIRED.filter { !File(dir, it).isFile }

    private fun resolve(base: DocumentFile, path: String): DocumentFile? {
        var cur: DocumentFile? = base
        for (p in path.split('/')) cur = cur?.findFile(p)
        return cur
    }

    fun missingInTree(base: DocumentFile) = REQUIRED.filter { resolve(base, it)?.isFile != true }

    // Ищем папку, внутри которой лежит hl2/
    fun findBase(root: DocumentFile): DocumentFile? {
        val candidates = listOfNotNull(
            root,
            root.findFile("Half-Life 2"),
            root.findFile("common")?.findFile("Half-Life 2")
        )
        return candidates.firstOrNull { it.findFile("hl2")?.isDirectory == true }
    }

    // Для zip: префикс папки перед hl2/gameinfo.txt
    fun zipPrefix(names: Collection<String>): String? =
        names.firstOrNull { it.endsWith("hl2/gameinfo.txt") }?.removeSuffix("hl2/gameinfo.txt")
}
