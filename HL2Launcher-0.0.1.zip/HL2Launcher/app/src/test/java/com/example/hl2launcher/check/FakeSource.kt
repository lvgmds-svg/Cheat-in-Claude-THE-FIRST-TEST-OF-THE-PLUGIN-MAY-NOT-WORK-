package com.example.hl2launcher.check

import com.example.hl2launcher.GameChecker

class FakeSource(
    private val files: Map<String, Long> = emptyMap(),
    private val heads: Map<String, ByteArray> = emptyMap(),
    private val texts: Map<String, String> = emptyMap(),
    private val manifest: String? = null
) : GameSource {
    override fun size(path: String) = files[path] ?: -1L
    override fun head(path: String, n: Int) = heads[path]
    override fun text(path: String) = texts[path]
    override fun topDirs() = files.keys.filter { '/' in it }.map { it.substringBefore('/') }.distinct()
    override fun totalSize(dirs: List<String>) =
        files.filter { (k, _) -> dirs.any { k.startsWith("$it/") } }.values.sum()
    override fun manifestText() = manifest

    companion object {
        val SIG = byteArrayOf(0x34, 0x12, 0xAA.toByte(), 0x55)
        const val GAMEINFO = "GameInfo\n{\n\tgame\t\"Half-Life 2\"\n\tFileSystem\n\t{\n\t\tSteamAppId\t\t220\n\t}\n}\n"
        const val ACF_OK = "\"AppState\"\n{\n\t\"appid\"\t\t\"220\"\n\t\"name\"\t\t\"Half-Life 2\"\n" +
            "\t\"StateFlags\"\t\t\"4\"\n\t\"buildid\"\t\t\"123\"\n\t\"LastOwner\"\t\t\"76561198000000000\"\n}\n"

        fun names() = GameChecker.REQUIRED + GameVerifier.CHUNKS

        fun good(
            extra: Map<String, Long> = emptyMap(),
            gameinfo: String = GAMEINFO,
            manifest: String? = ACF_OK,
            sizes: Map<String, Long> = emptyMap(),
            heads: Map<String, ByteArray> = emptyMap(),
            drop: Set<String> = emptySet()
        ): FakeSource {
            val files = names().filter { it !in drop }.associateWith { 1000L } + extra + sizes
            val h = names().filter { it.endsWith("_dir.vpk") }.associateWith { SIG } + heads
            return FakeSource(files, h, mapOf("hl2/gameinfo.txt" to gameinfo), manifest)
        }
    }
}
