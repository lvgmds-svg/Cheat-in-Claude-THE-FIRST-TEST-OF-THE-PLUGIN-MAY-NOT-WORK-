package com.example.hl2launcher.check

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class GameVerifierTest {
    private fun types(r: VerifyResult) = r.issues.map { it.type }

    @Test fun goodCopyPasses() {
        val r = GameVerifier.verify(FakeSource.good(), 10_000_000_000L, strict = true)
        assertTrue(r.ok)
        assertEquals(220, r.license?.appId)
        assertEquals("Half-Life 2", r.gameTitle)
    }

    @Test fun portalFolderIsOtherGame() {
        val src = FakeSource(files = mapOf("portal/gameinfo.txt" to 500L))
        val r = GameVerifier.verify(src, null, strict = true)
        assertEquals(listOf(ErrorType.OTHER_GAME), types(r))
        assertTrue(r.issues[0].detail.contains("Portal"))
    }

    @Test fun emptyFolderIsNotSourceGame() {
        val r = GameVerifier.verify(FakeSource(), null, strict = true)
        assertEquals(listOf(ErrorType.NOT_SOURCE_GAME), types(r))
    }

    @Test fun otherAppIdInGameinfo() {
        val gi = FakeSource.GAMEINFO.replace("220", "400")
        val r = GameVerifier.verify(FakeSource.good(gameinfo = gi), null, strict = false)
        assertTrue(ErrorType.OTHER_GAME in types(r))
    }

    @Test fun extraGameFolderStrictVsLoose() {
        val extra = mapOf("episodic/gameinfo.txt" to 500L)
        val strict = GameVerifier.verify(FakeSource.good(extra = extra), null, strict = true)
        assertTrue(ErrorType.OTHER_GAME_FILES in types(strict))
        val loose = GameVerifier.verify(FakeSource.good(extra = extra), null, strict = false)
        assertTrue(loose.ok)
    }

    @Test fun missingFileReported() {
        val r = GameVerifier.verify(FakeSource.good(drop = setOf("hl2/hl2_misc_dir.vpk")), null, strict = true)
        assertTrue(ErrorType.MISSING_FILES in types(r))
        assertTrue(r.issues.first { it.type == ErrorType.MISSING_FILES }.detail.contains("hl2_misc_dir.vpk"))
    }

    @Test fun badVpkSignature() {
        val bad = mapOf("hl2/hl2_pak_dir.vpk" to byteArrayOf(1, 2, 3, 4))
        val r = GameVerifier.verify(FakeSource.good(heads = bad), null, strict = true)
        assertTrue(ErrorType.CORRUPT_FILE in types(r))
    }

    @Test fun emptyVpkIsCorrupt() {
        val r = GameVerifier.verify(FakeSource.good(sizes = mapOf("hl2/hl2_pak_dir.vpk" to 0L)), null, strict = true)
        assertTrue(ErrorType.CORRUPT_FILE in types(r))
    }

    @Test fun notFullyInstalledManifest() {
        val acf = FakeSource.ACF_OK.replace("\"4\"", "\"1026\"")
        val r = GameVerifier.verify(FakeSource.good(manifest = acf), null, strict = true)
        assertTrue(ErrorType.LICENSE_BAD in types(r))
    }

    @Test fun missingManifestIsOnlyWarning() {
        val r = GameVerifier.verify(FakeSource.good(manifest = null), null, strict = true)
        assertTrue(r.ok)
        assertEquals(listOf(ErrorType.LICENSE_NOT_FOUND), types(r))
    }

    @Test fun notEnoughSpace() {
        val r = GameVerifier.verify(FakeSource.good(), 100L, strict = true)
        assertTrue(ErrorType.NO_SPACE in types(r))
    }
}
